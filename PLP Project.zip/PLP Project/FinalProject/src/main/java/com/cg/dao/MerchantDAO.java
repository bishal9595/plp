package com.cg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Merchant;
import com.cg.bean.Product;

public interface MerchantDAO extends JpaRepository<Merchant, Integer> {
	@Query("select m.password from Merchant m where m.emailid=?1")
	public String getMerchantPassword(String emailId);

	@Query("select u from Merchant u where u.emailid=?1")
	public Merchant existsByEmail(String emailId);

	@Transactional
	@Modifying
	@Query("update Merchant m set m.rating=?2 where m.merchantId=?1")
	public void updateMerchantRating(Integer merchantId, Double rating);

	@Transactional
	@Modifying
	@Query("update Merchant u set u.password=?2 where u.emailid=?1")
	public void updatepassword(String email, String password);

	@Query("SELECT m FROM Merchant m WHERE m.emailid = ?1")
	public Merchant existsByEmailId(String emailId);

	@Query("select p from Product p where p.merchant=?1")
	List<Product> findAllProductWithMerchantId(Merchant merchantObject);

	@Query("select p from Product p where p.merchant=?2 AND p.productID=?1")
	List<Product> findByProductIdWithMerchantId(int productId, Merchant merchantObject);

	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.productName) LIKE UPPER(?1)")
	List<Product> findByProductNameWithMerchantId(String productName, Merchant merchantObject);

	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.company) LIKE UPPER(?1)")
	List<Product> findByCompanyWithMerchantId(String Company, Merchant merchantObject);

	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.category) LIKE UPPER(?1)")
	List<Product> findByCategoryWithMerchantId(String Category, Merchant merchantObject);

	@Query("select p from Product p where p.merchant=?2 AND UPPER(p.subcategory) LIKE UPPER(?1)")
	List<Product> findBySubCategoryWithMerchantId(String subcategory, Merchant merchantObject);

	@Query("select m from Merchant m")
	List<Merchant> findAllMerchant();

	@Query("select m from Merchant m where m.merchantId=?1")
	List<Merchant> findByMerchantId(Integer MerchantId);

}
