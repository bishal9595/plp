package com.cg.dao;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.bean.Merchant;
import com.cg.bean.Product;

@Repository
public class ProductDAOImpl1 implements ProductDAO1 {

	@PersistenceContext
	EntityManager em;

	@Autowired
	TransactionDAO1 transaction;

	@Override
	public List<Product> product(int orderid) {

		List<Integer> productid = transaction.productidorder(orderid);
		List<Product> productslist = new ArrayList<Product>();
		for (Integer i : productid) {
			Query query = em.createQuery("select p from Product p where p.productID = :productid");
			Product product = (Product) query.setParameter("productid", i).getSingleResult();
			productslist.add(product);
		}
		return productslist;
	}

	@Override
	public Product getProduct(int productid) {

		Query query = em.createQuery("select p from Product p where p.productID = :productid");
		Product product = (Product) query.setParameter("productid", productid).getSingleResult();
		return product;
	}

	@Override
	public List<Merchant> merchantid(int orderid) {

		List<Integer> productid = transaction.productidorder(orderid);
		List<Merchant> merchants = new ArrayList<Merchant>();
		for (Integer i : productid) {
			Query query = em.createQuery("select p from Product p where p.productID = :productid");
			Product product = (Product) query.setParameter("productid", i).getSingleResult();
			Merchant mer = product.getMerchant();
			merchants.add(mer);
		}
		return merchants;
	}

}
