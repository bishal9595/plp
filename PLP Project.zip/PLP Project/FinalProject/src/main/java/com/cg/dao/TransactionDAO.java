package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Transaction;
import com.cg.bean.User1;

public interface TransactionDAO extends JpaRepository<Transaction, Integer>{

	@Query("select t from Transaction t where t.transactionId=?1")
	public Transaction gettransaction(int id);


	@Query("select t from Transaction t where t.user=?1")
	public List<Transaction> getAllTransactionByUser(User1 user);
}
