import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { dataService } from '../../Services/dataServiceMerchant';
import { Product } from 'src/app/models/product';



// export class Product{
//     constructor(
//         public productID:number,
//         public productName:String ,
//         //public merchant:null,
//         //public tag:null,
//         public company:String,
//         public photo:String,
//         public description:String,
//         public quantity:number,
//         public catagory:String,
//         public subcategory:String,
//         public soldQuantantities:number,
//         public price:number,
//         public releaseDate:Date
//     ){}
//}
@Component({
    selector: 'inventoryControl',
    templateUrl: 'inventory.html'
})

export class InventoryControlComponent { 
 
    inv:Product[];
    mid:number

    ngOnInit(): void
    {
        this.refreshInventory();
}


    constructor(private service :dataService, private route:Router){}


    refreshInventory(){
        this.service.fetchInventory(this.mid).subscribe(
            response=>{
                console.log(response)
                this.inv = response
            }
        );
    }


    addProduct()
    {
        this.route.navigate(['addProduct'])
    }
}