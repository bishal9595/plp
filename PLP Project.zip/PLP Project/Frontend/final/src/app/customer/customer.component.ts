import { Component } from "@angular/core";

@Component({
    selector:'cust',
    templateUrl:'customer.html'
})
export class Customer{
    constructor(){}
}