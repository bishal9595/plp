import { User1 } from "./User";



export class Transaction {

    transactionId: number;
  //  transaction: Transaction;
    //product: Product;
   // returnStatus: String;
   modeOfPurchase:string;
   status:string;
   user:User1;
   products:any;
   

  }