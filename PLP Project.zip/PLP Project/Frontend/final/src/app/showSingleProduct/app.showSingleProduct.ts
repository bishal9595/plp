import { Component,} from "@angular/core";
import {ProductSingleService} from '../Services/showSingleProductService';
import {Product} from '../models/Product';
import {Router, RouterModule, Routes} from '@angular/router';

@Component({
    selector:'show-product',
    templateUrl:'showproduct.html'
})

export class ShowProductSingleComponent {
    constructor(private service:ProductSingleService, private router:Router){

    }
    products:Product[]=[];

    similarProducts: Product[] = []

    product:Product;
   result:any;

    pid: string;
    uid: string;
    str:string


    ngOnInit(): void {
       // throw new Error("Method not implemented.");
       this.pid = sessionStorage.getItem('productId')
        this.uid = sessionStorage.getItem("user")        
        this.service.findproduct(this.pid).subscribe(
            res=>{
               this.product=res
                this.service.getsimilarProduct(this.product.category, this.product.subcategory, this.product.productID).subscribe(
                    data=>{
                        this.similarProducts = data;
                    }, err=>console.log(err)
                )
            },
            err=>{
                alert("Product Not found")
            }
        )
        
        //this.finddata();
       } 

       addToWishlist(){
           this.str = sessionStorage.getItem('user')
           if(this.str != null )
           {
            this.service.addWishList(this.pid,this.uid).subscribe(data=>{this.result=data;alert(this.result.status)})
           }
           else{
               this.router.navigate(['login'])
           }
        
       }
       addToCart(){
        this.str = sessionStorage.getItem('user')
        if(this.str != null )
        {
         this.service.addCart(this.pid,this.uid).subscribe(data=>{this.result=data;alert(this.result.status)});
        }
        else{
            this.router.navigate(['login'])
        }
       }

       showProduct(index: number){
        let productId = this.similarProducts[index].productID;
        sessionStorage.setItem('productId',""+productId)
        //let a = sessionStorage.getItem('productId')
        window.location.reload();
       }
}