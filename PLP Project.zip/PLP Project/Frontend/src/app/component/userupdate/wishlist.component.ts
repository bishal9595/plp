// import {Component} from '@angular/core'
// import { user } from "./customer";


// @Component({
//     selector:'wishlist',
//     templateUrl:'wishlist.html'
// })

// export class wishlist{
//     public wishlistId:number;
//     public name:string;
//     //public user:user;
//    // public list:string;
//     constructor(wishlistId,name){}
// }