package com.cg.bean;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Temp {
	
	private int pid;
    private String productName;
	private Integer  amount;
	private int quantity;
	public Temp() {
		// TODO Auto-generated constructor stub
	}
	public Temp(int pid, String productName, Integer amount, int quantity) {
		super();
		this.pid = pid;
		this.productName = productName;
		this.amount = amount;
		this.quantity = quantity;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Temp [pid=" + pid + ", productName=" + productName + ", amount=" + amount + ", quantity=" + quantity
				+ "]";
	}
	
	
	

}
