package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Temp;
import com.cg.services.CartService;

@CrossOrigin("http://localhost:4200")

@RestController
@RequestMapping("/capstore")
public class CartController {
	
	 @Autowired
	 CartService service;
	 
	 @GetMapping(value = "/get/{id}")
		public List<Temp> getAll(@PathVariable Integer id) {
		    System.out.println("in controller");
		    
		    
		    
		    
		    
	    return service.DisplayFromCart(id);
		}
	 
	 @PostMapping(value="/new",consumes= {"application/json"})
	    public String save(@RequestBody Cart cart) {
	        service.AddToCart(cart);
	        return "Detail added!";
	    }
	 @DeleteMapping(value="/delete/{id}/{id1}",consumes= {"application/json"})
	    public String delete(@PathVariable Integer id,@PathVariable Integer id1) {
	        service.RemoveFromCart(id,id1);
	        return "Detail removed!";
	    }
	
	 @GetMapping(value = "/checkminprice/{uid}")
	 public boolean getMinimumPrice(@PathVariable Integer uid) {
		 return service.checkMinPrice(uid);
	 }
}
