package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Cart;
import com.cg.bean.User1;

public interface CartRepo extends JpaRepository<Cart, Integer> {
	
	@Query("from Cart c where c.user=?1")
	public Cart findCartByUser(User1 user);
}
	


