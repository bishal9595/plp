package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.Cart;
import com.cg.bean.Product;

public interface ProductRepo extends JpaRepository<Product, Integer> {
	

}
