package com.cg.services;

import java.util.List;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Temp;

public interface CartService {
	
	public void AddToCart(Cart c);
	public  void RemoveFromCart(int uid,int pid);
	  public List<Temp> DisplayFromCart(int uid);
	public boolean checkMinPrice(Integer cartid);
	
	//public  List<Cart> getAllCartDetails();
	//public List<Integer> list(Integer id);
	
	//Cart getAllCartDetailsOfAParticularUser(int userId);
  
}
