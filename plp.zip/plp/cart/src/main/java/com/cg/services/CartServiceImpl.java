package com.cg.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Temp;
import com.cg.bean.User1;
import com.cg.daos.CartRepo;
import com.cg.daos.ProductRepo;
import com.cg.daos.UserRepo;

@Service
public class CartServiceImpl implements CartService {
    @Autowired
    CartRepo cartDao;
    @Autowired
    UserRepo userdao;
    @Autowired
    ProductRepo prodDao;
	
    User1 user;

	@Override
	public void AddToCart(Cart c) {
		// TODO Auto-generated method stub
		cartDao.save(c);
	}

	@Override
	public void RemoveFromCart(int uid,int pid) {
		// TODO Auto-generated method stub
		user= userdao.findById(uid).get();
		Cart cart=cartDao.findCartByUser(user);
		List<Integer[]> products=cart.getProducts();
		Optional<Product> prod=prodDao.findById(pid);
		Product product=prod.get();
		int position=products.indexOf(product);
		products.remove(position);
	    cart.setProducts(products);
	    cartDao.save(cart);	
		
	}

	@Override
	public List<Temp> DisplayFromCart(int uid) {
		// TODO Auto-generated method stub
		user= userdao.findById(uid).get();
		System.out.println("in display cart");
		Cart cart=cartDao.findCartByUser(user);
		//Cart cart=cartDao.findById(uid).get();
		List<Integer[]> products=cart.getProducts();
		
		System.out.println(products);
		
		List<Temp> tlist = new ArrayList<Temp>();
        
		for(Integer[] arr : products) {
			int pid = arr[0];
			
			Product productObject=prodDao.findById(pid).get();
			int quantity=arr[1];
			String productName=productObject.getProductName();
			Integer amount=productObject.getPrice();
			
			Temp t=new Temp(pid,productName,amount,quantity);
			
			tlist.add(t);
			System.out.println(tlist);
		}
		
		return tlist;
	}

	@Override
	public boolean checkMinPrice(Integer uid) {
		// TODO Auto-generated method stub
		user= userdao.findById(uid).get();
		Cart cart=cartDao.findCartByUser(user);
		Double amount=cart.getAmount();
		if(amount<1000.0)
		return false;
		else
			return true;
	}
	
	
	
	
	
   
}
