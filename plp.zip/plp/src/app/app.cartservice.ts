import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {Observable} from 'rxjs';
//import { Temp } from './model/Temp';


let baseUrl = "http://localhost:4990/capstore";
let options = { "headers": 
new HttpHeaders({"Content-Type": "application/json" }) };

@Injectable({
    providedIn:'root'
})

export class CartService{
    constructor(private http:HttpClient){
    
    }

    

    getCart(id:number)
    {       
       
          return this.http.get<any>(baseUrl+"/get/"+id);
    }
    

    delete(id:number,id1:number):Observable<any>{
        return this.http.delete<any>(baseUrl+"/delete/"+id+"/"+id1,options)
    }

    getMinPrice(id:number):any{
        return this.http.get<any>(baseUrl+"/getMinPrice/"+id)
    }


 /*  place_order(cartId:number):any
   {
       return this.http.get<number>(baseUrl+"/placingorder/"+cartId,options)
   }*/
}

   