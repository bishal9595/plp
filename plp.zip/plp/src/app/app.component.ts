﻿import { Component, OnInit } from '@angular/core';
import {CartService} from './app.cartservice';
import { Temp } from './model/Temp';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent  implements OnInit {

     id:number
     id1:number
     cart:any
     cartAll:Temp[]=[]
     uid:number
     price:number
     check:boolean=false
      cartId:number
    constructor(private service:CartService)
    {
        
    }
    ngOnInit(){
        
        this.service.getCart(this.uid).subscribe(res=>this.cartAll=res)
    }
    
    deleteCart(id:number)
    {
        this.service.delete(this.id,this.id1).subscribe(
            res=>{
                console.log(res)
            }
        )
    }

    giveErrorMinPrice(){
        this.price=this.service.getMinPrice(this.uid).subscribe(data=> this.check=data )

        if(this.check)
        alert("You can place order")
        else
        alert("You can not place order below minimum price Rs.1000")
        }

       /* placeOrder()
        {
            this.service.place_order(this.cartId).subscribe(data=>console.log(data))
        }*/
}