export class Temp{
    
    productName:String;
    quantity:number;
    pid:number
    amount:number;
    constructor(pid,productName,amount,quantity)
    {   this.pid=pid;
        this.productName=productName;
        this. quantity= quantity;
        this.amount=amount;
    }
}